import React, { useEffect, useState } from "react";
import "./App.css";

const Countdown = ({ label, targetDate }) => {
  const [timeLeft, setTimeLeft] = useState("Loading...");

  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date();
      const diff = new Date(targetDate) - now;

      if (diff <= 0) {
        setTimeLeft(`${label} is here! 💜`);
        clearInterval(interval);
        return;
      }

      const d = Math.floor(diff / (1000 * 60 * 60 * 24));
      const h = Math.floor((diff / (1000 * 60 * 60)) % 24);
      const m = Math.floor((diff / (1000 * 60)) % 60);
      const s = Math.floor((diff / 1000) % 60);
      setTimeLeft(`${d}d ${h}h ${m}m ${s}s`);
    }, 1000);

    return () => clearInterval(interval);
  }, [targetDate, label]);

  return (
    <div className="countdown-box">
      <h3>{label}</h3>
      <p>{timeLeft}</p>
    </div>
  );
};

const App = () => {
  const [showLetter, setShowLetter] = useState(false);

  return (
    <div className="App">
      <div className="petals" />
      <h1>Dear Bhawna</h1>
      <h2>A soft dreamy countdown — from your Prateek 💖</h2>

      <div className="countdown-container">
        <Countdown label="Her Birthday 🎂" targetDate="2025-08-06T00:00:00" />
        <Countdown label="First Day We Met ✨" targetDate="2025-12-25T00:00:00" />
      </div>

      <button className="btn-love" onClick={() => setShowLetter(true)}>Open Love Letter 💌</button>

      {showLetter && (
        <div className="modal">
          <div className="modal-content">
            <p>
              My dearest Bhawna,<br /><br />
              I don’t think there are enough words to express how much you mean to me.
              Every moment we’ve shared, every smile, every silence — they all echo in my heart like a soft melody.<br /><br />
              You’ve brought light into my life in the most unexpected ways. Just the thought of you makes my ordinary days feel extraordinary.
              I’m grateful for every second with you, and I can’t wait to see where life takes us next — hand in hand.<br /><br />
              Always yours,<br /><strong>Prateek</strong>
            </p>
            <button className="btn-close" onClick={() => setShowLetter(false)}>Close</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
